import React, { useState } from 'react';
import { useDrag } from 'react-dnd';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { DesignComponent } from '../App';
import { 
  Server, Database, Zap, Globe, Monitor, HardDrive, Cloud, Container, 
  MessageSquare, Shield, Key, Code, Smartphone, Archive, 
  Search, Layers, Activity, Box
} from 'lucide-react';

interface ComponentType {
  type: DesignComponent['type'];
  label: string;
  icon: React.ComponentType<any>;
  color: string;
  category: 'popular' | 'compute' | 'storage' | 'network' | 'other';
}

// Simplified, most commonly used components
const popularComponents: ComponentType[] = [
  // Most Popular
  { type: 'server', label: 'Server', icon: Server, color: 'bg-blue-500', category: 'popular' },
  { type: 'database', label: 'Database', icon: Database, color: 'bg-green-500', category: 'popular' },
  { type: 'load-balancer', label: 'Load Balancer', icon: Zap, color: 'bg-purple-500', category: 'popular' },
  { type: 'api-gateway', label: 'API Gateway', icon: Globe, color: 'bg-red-500', category: 'popular' },
  { type: 'cache', label: 'Cache', icon: HardDrive, color: 'bg-orange-500', category: 'popular' },
  { type: 'message-queue', label: 'Message Queue', icon: MessageSquare, color: 'bg-amber-500', category: 'popular' },

  // Compute
  { type: 'microservice', label: 'Microservice', icon: Box, color: 'bg-blue-400', category: 'compute' },
  { type: 'container', label: 'Container', icon: Container, color: 'bg-cyan-500', category: 'compute' },
  { type: 'serverless', label: 'Serverless', icon: Cloud, color: 'bg-sky-500', category: 'compute' },

  // Storage
  { type: 'redis', label: 'Redis', icon: HardDrive, color: 'bg-red-600', category: 'storage' },
  { type: 'postgresql', label: 'PostgreSQL', icon: Database, color: 'bg-blue-800', category: 'storage' },
  { type: 'mongodb', label: 'MongoDB', icon: Database, color: 'bg-green-600', category: 'storage' },
  { type: 's3', label: 'AWS S3', icon: Archive, color: 'bg-orange-500', category: 'storage' },

  // Network
  { type: 'cdn', label: 'CDN', icon: Cloud, color: 'bg-purple-600', category: 'network' },
  { type: 'firewall', label: 'Firewall', icon: Shield, color: 'bg-red-700', category: 'network' },
  { type: 'rest-api', label: 'REST API', icon: Code, color: 'bg-emerald-500', category: 'network' },

  // Clients & Other
  { type: 'web-app', label: 'Web App', icon: Globe, color: 'bg-blue-600', category: 'other' },
  { type: 'mobile-app', label: 'Mobile App', icon: Smartphone, color: 'bg-green-600', category: 'other' },
  { type: 'monitoring', label: 'Monitoring', icon: Activity, color: 'bg-blue-500', category: 'other' },
  { type: 'authentication', label: 'Auth', icon: Key, color: 'bg-yellow-600', category: 'other' },
];

const categories = [
  { id: 'popular', label: 'Popular', components: popularComponents.filter(c => c.category === 'popular') },
  { id: 'compute', label: 'Compute', components: popularComponents.filter(c => c.category === 'compute') },
  { id: 'storage', label: 'Storage', components: popularComponents.filter(c => c.category === 'storage') },
  { id: 'network', label: 'Network', components: popularComponents.filter(c => c.category === 'network') },
  { id: 'other', label: 'Other', components: popularComponents.filter(c => c.category === 'other') },
];

interface DraggableComponentProps extends ComponentType {}

function DraggableComponent({ type, label, icon: Icon, color }: DraggableComponentProps) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'component',
    item: { type },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  return (
    <div
      ref={drag}
      className={`
        group p-2 rounded-lg border border-border/50 cursor-move transition-all duration-200
        hover:border-primary/50 hover:bg-accent/30 hover:shadow-sm hover:scale-[1.02]
        active:scale-95 bg-card/30 backdrop-blur-sm
        ${isDragging ? 'opacity-50 rotate-1 scale-105 border-primary shadow-lg' : ''}
      `}
      title={`Drag ${label} to canvas`}
    >
      <div className="flex items-center space-x-2">
        <div className={`w-6 h-6 rounded ${color} flex items-center justify-center transition-all duration-200 group-hover:scale-110 shadow-sm`}>
          <Icon className="w-3 h-3 text-white" />
        </div>
        <span className="text-sm font-medium truncate flex-1">{label}</span>
      </div>
    </div>
  );
}

export function SimplifiedComponentLibrary() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('popular');

  const filteredComponents = popularComponents.filter(component =>
    component.label.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (activeCategory === 'all' || component.category === activeCategory)
  );

  const activeComponents = activeCategory === 'all' 
    ? filteredComponents 
    : categories.find(c => c.id === activeCategory)?.components.filter(component =>
        component.label.toLowerCase().includes(searchQuery.toLowerCase())
      ) || [];

  return (
    <div className="h-full flex flex-col">
      {/* Search */}
      <div className="p-4 border-b border-border/30">
        <Input
          placeholder="Search components..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="text-sm bg-background/50 backdrop-blur-sm border-border/30 focus:bg-background/80 transition-all duration-200"
          icon={<Search className="w-4 h-4" />}
        />
      </div>

      {/* Category Tabs */}
      <div className="px-4 py-2 border-b border-border/30">
        <div className="flex flex-wrap gap-1">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={activeCategory === category.id ? "default" : "ghost"}
              size="sm"
              onClick={() => setActiveCategory(category.id)}
              className="text-xs h-7 px-2 flex items-center gap-1"
            >
              {category.label}
              <Badge 
                variant={activeCategory === category.id ? "secondary" : "outline"} 
                className="text-xs h-4 px-1 ml-1"
              >
                {category.components.length}
              </Badge>
            </Button>
          ))}
        </div>
      </div>

      {/* Components Grid */}
      <div className="flex-1 p-4">
        <ScrollArea className="h-full">
          <div className="space-y-1">
            {activeComponents.length > 0 ? (
              activeComponents.map((component) => (
                <DraggableComponent key={component.type} {...component} />
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Layers className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No components found</p>
                <p className="text-xs">Try adjusting your search</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}