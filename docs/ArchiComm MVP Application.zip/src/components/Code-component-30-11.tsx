import React from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Progress } from './ui/progress';
import { Challenge } from '../App';
import { ExtendedChallenge } from '../lib/challenge-config';
import { 
  Clock, 
  Target, 
  CheckCircle2, 
  AlertCircle,
  BookOpen,
  Zap,
  Users,
  Server,
  Database,
  Network
} from 'lucide-react';

interface AssignmentPanelProps {
  challenge: Challenge | ExtendedChallenge;
  progress?: {
    componentsCount: number;
    connectionsCount: number;
    timeElapsed: number;
  };
  currentComponents?: any[];
}

const getDifficultyIcon = (difficulty: Challenge['difficulty']) => {
  switch (difficulty) {
    case 'beginner':
      return <Zap className="w-4 h-4 text-green-500" />;
    case 'intermediate':
      return <Target className="w-4 h-4 text-yellow-500" />;
    case 'advanced':
      return <AlertCircle className="w-4 h-4 text-red-500" />;
    default:
      return <Target className="w-4 h-4 text-gray-500" />;
  }
};

const getDifficultyColor = (difficulty: Challenge['difficulty']) => {
  switch (difficulty) {
    case 'beginner':
      return 'bg-green-100 text-green-800 border-green-200';
    case 'intermediate':
      return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    case 'advanced':
      return 'bg-red-100 text-red-800 border-red-200';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-200';
  }
};

const getCategoryIcon = (category: Challenge['category']) => {
  switch (category) {
    case 'system-design':
      return <Server className="w-4 h-4" />;
    case 'architecture':
      return <Database className="w-4 h-4" />;
    case 'scaling':
      return <Network className="w-4 h-4" />;
    default:
      return <BookOpen className="w-4 h-4" />;
  }
};

export function AssignmentPanel({ challenge, progress, currentComponents = [] }: AssignmentPanelProps) {
  const extendedChallenge = challenge as ExtendedChallenge;
  const hasExtendedData = 'keyComponents' in extendedChallenge;
  
  const completedRequirements = challenge.requirements.filter((req, index) => {
    // Simple heuristic based on components added
    return currentComponents.length > index;
  });

  const progressPercentage = (completedRequirements.length / challenge.requirements.length) * 100;

  return (
    <div className="w-80 bg-card/30 backdrop-blur-sm border-r border-border/30 flex flex-col h-full">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="p-4 border-b border-border/30"
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-2">
            {getCategoryIcon(challenge.category)}
            <Badge variant="outline" className="text-xs">
              {challenge.category.replace('-', ' ')}
            </Badge>
          </div>
          <div className="flex items-center space-x-1">
            {getDifficultyIcon(challenge.difficulty)}
            <Badge className={`text-xs ${getDifficultyColor(challenge.difficulty)}`}>
              {challenge.difficulty}
            </Badge>
          </div>
        </div>
        
        <h2 className="font-semibold text-lg mb-2 leading-tight">{challenge.title}</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">{challenge.description}</p>
        
        <div className="flex items-center justify-between mt-4 text-xs text-muted-foreground">
          <div className="flex items-center space-x-1">
            <Clock className="w-3 h-3" />
            <span>{challenge.estimatedTime} min</span>
          </div>
          <div className="flex items-center space-x-1">
            <Users className="w-3 h-3" />
            <span>Individual</span>
          </div>
        </div>
      </motion.div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {/* Progress Section */}
          {progress && (
            <Card className="bg-card/50 backdrop-blur-sm border-border/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                  Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0 space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span>Requirements</span>
                    <span>{completedRequirements.length}/{challenge.requirements.length}</span>
                  </div>
                  <Progress value={progressPercentage} className="h-2" />
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-muted/50 rounded p-2">
                    <div className="text-muted-foreground">Components</div>
                    <div className="font-medium">{progress.componentsCount}</div>
                  </div>
                  <div className="bg-muted/50 rounded p-2">
                    <div className="text-muted-foreground">Connections</div>
                    <div className="font-medium">{progress.connectionsCount}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Requirements Section */}
          <Card className="bg-card/50 backdrop-blur-sm border-border/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-accent"></div>
                Requirements
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {challenge.requirements.map((requirement, index) => {
                  const isCompleted = completedRequirements.includes(requirement);
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`flex items-start space-x-2 p-2 rounded-lg transition-all ${
                        isCompleted 
                          ? 'bg-green-50 border border-green-200' 
                          : 'bg-muted/30 border border-border/20'
                      }`}
                    >
                      <div className={`mt-0.5 flex-shrink-0 ${
                        isCompleted ? 'text-green-600' : 'text-muted-foreground'
                      }`}>
                        {isCompleted ? (
                          <CheckCircle2 className="w-4 h-4" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border-2 border-current opacity-50" />
                        )}
                      </div>
                      <span className={`text-sm leading-relaxed ${
                        isCompleted ? 'text-green-800 font-medium' : 'text-foreground'
                      }`}>
                        {requirement}
                      </span>
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Key Components (if available) */}
          {hasExtendedData && extendedChallenge.keyComponents && (
            <Card className="bg-card/50 backdrop-blur-sm border-border/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                  Key Components
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex flex-wrap gap-1">
                  {extendedChallenge.keyComponents.map((component, index) => (
                    <Badge 
                      key={index} 
                      variant="outline" 
                      className="text-xs bg-background/50"
                    >
                      {component}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Considerations (if available) */}
          {hasExtendedData && extendedChallenge.considerations && (
            <Card className="bg-card/50 backdrop-blur-sm border-border/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                  Considerations
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  {extendedChallenge.considerations.map((consideration, index) => (
                    <div key={index} className="text-sm text-muted-foreground leading-relaxed">
                      • {consideration}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </ScrollArea>

      {/* Tips Section */}
      <div className="p-4 border-t border-border/30 bg-gradient-to-r from-muted/20 via-card to-muted/10">
        <div className="text-xs text-muted-foreground">
          💡 <strong>Tip:</strong> Start with core components and build outward. Consider scalability and data flow.
        </div>
      </div>
    </div>
  );
}