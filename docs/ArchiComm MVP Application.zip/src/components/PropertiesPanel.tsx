import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { DesignComponent, Connection } from '../App';
import { SimplifiedComponentLibrary } from './SimplifiedComponentLibrary';
import { 
  Settings, 
  Trash2, 
  Edit3, 
  Link, 
  Palette,
  Info,
  Layers
} from 'lucide-react';

interface PropertiesPanelProps {
  selectedComponent: string | null;
  components: DesignComponent[];
  connections: Connection[];
  connectionMode: boolean;
  onComponentLabelChange: (id: string, label: string) => void;
  onComponentDelete: (id: string) => void;
  onConnectionModeToggle: () => void;
  onConnectionCancel: () => void;
  connectionStart: string | null;
}

export function PropertiesPanel({
  selectedComponent,
  components,
  connections,
  connectionMode,
  onComponentLabelChange,
  onComponentDelete,
  onConnectionModeToggle,
  onConnectionCancel,
  connectionStart
}: PropertiesPanelProps) {
  const [activeTab, setActiveTab] = useState('components');
  
  const selectedComponentData = selectedComponent 
    ? components.find(c => c.id === selectedComponent)
    : null;

  const componentConnections = selectedComponent 
    ? connections.filter(c => c.from === selectedComponent || c.to === selectedComponent)
    : [];

  return (
    <div className="w-80 bg-card/30 backdrop-blur-sm border-l border-border/30 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border/30">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Properties
          </h3>
          {selectedComponent && (
            <Badge variant="outline" className="text-xs">
              {components.length} components
            </Badge>
          )}
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 h-8">
            <TabsTrigger value="components" className="text-xs">
              <Layers className="w-3 h-3 mr-1" />
              Library
            </TabsTrigger>
            <TabsTrigger value="properties" className="text-xs">
              <Edit3 className="w-3 h-3 mr-1" />
              Properties
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="flex-1 overflow-hidden">
        <Tabs value={activeTab} className="h-full flex flex-col">
          {/* Component Library Tab */}
          <TabsContent value="components" className="flex-1 m-0 overflow-hidden">
            <SimplifiedComponentLibrary />
          </TabsContent>

          {/* Properties Tab */}
          <TabsContent value="properties" className="flex-1 m-0 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="p-4 space-y-4">
                {/* Connection Controls */}
                <Card className="bg-card/50 backdrop-blur-sm border-border/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Link className="w-4 h-4 text-primary" />
                      Connections
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0 space-y-3">
                    <Button
                      variant={connectionMode ? "default" : "outline"}
                      size="sm"
                      onClick={onConnectionModeToggle}
                      className="w-full"
                    >
                      {connectionMode ? (
                        <>
                          <Link className="w-4 h-4 mr-2" />
                          Cancel Connection
                        </>
                      ) : (
                        <>
                          <Link className="w-4 h-4 mr-2" />
                          Add Connection
                        </>
                      )}
                    </Button>
                    
                    {connectionMode && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="text-xs text-muted-foreground bg-muted/30 p-2 rounded"
                      >
                        {connectionStart ? (
                          <>
                            <div className="font-medium text-primary mb-1">Step 2:</div>
                            Click the target component to create connection
                          </>
                        ) : (
                          <>
                            <div className="font-medium text-primary mb-1">Step 1:</div>
                            Click the source component to start
                          </>
                        )}
                      </motion.div>
                    )}
                  </CardContent>
                </Card>

                {/* Selected Component Properties */}
                {selectedComponentData ? (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <Card className="bg-card/50 backdrop-blur-sm border-border/30">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <Palette className="w-4 h-4 text-accent" />
                          Component Details
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0 space-y-4">
                        {/* Component Type */}
                        <div>
                          <label className="text-xs font-medium block mb-1 text-muted-foreground">
                            Type
                          </label>
                          <Badge variant="outline" className="text-xs">
                            {selectedComponentData.type.replace('-', ' ')}
                          </Badge>
                        </div>

                        {/* Component Label */}
                        <div>
                          <label className="text-xs font-medium block mb-1 text-muted-foreground">
                            Label
                          </label>
                          <Input
                            value={selectedComponentData.label}
                            onChange={(e) => onComponentLabelChange(selectedComponentData.id, e.target.value)}
                            size="sm"
                            className="text-xs"
                            placeholder="Enter component label..."
                          />
                        </div>

                        {/* Position */}
                        <div>
                          <label className="text-xs font-medium block mb-1 text-muted-foreground">
                            Position
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            <div className="bg-muted/30 rounded p-2">
                              <div className="text-xs text-muted-foreground">X</div>
                              <div className="text-xs font-medium">{Math.round(selectedComponentData.x)}</div>
                            </div>
                            <div className="bg-muted/30 rounded p-2">
                              <div className="text-xs text-muted-foreground">Y</div>
                              <div className="text-xs font-medium">{Math.round(selectedComponentData.y)}</div>
                            </div>
                          </div>
                        </div>

                        {/* Connected Components */}
                        {componentConnections.length > 0 && (
                          <div>
                            <label className="text-xs font-medium block mb-2 text-muted-foreground">
                              Connections ({componentConnections.length})
                            </label>
                            <div className="space-y-1">
                              {componentConnections.map((connection) => {
                                const isSource = connection.from === selectedComponent;
                                const otherComponentId = isSource ? connection.to : connection.from;
                                const otherComponent = components.find(c => c.id === otherComponentId);
                                
                                return (
                                  <div key={connection.id} className="bg-muted/30 rounded p-2 text-xs">
                                    <div className="flex items-center justify-between">
                                      <span className={isSource ? 'text-blue-600' : 'text-green-600'}>
                                        {isSource ? '→' : '←'} {otherComponent?.label || 'Unknown'}
                                      </span>
                                      <Badge variant="outline" className="text-xs h-4">
                                        {connection.type}
                                      </Badge>
                                    </div>
                                    {connection.label && (
                                      <div className="text-muted-foreground mt-1">
                                        {connection.label}
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        {/* Actions */}
                        <div className="pt-2 border-t border-border/30">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => onComponentDelete(selectedComponentData.id)}
                            className="w-full text-xs"
                            title="Delete Component"
                          >
                            <Trash2 className="w-3 h-3 mr-2" />
                            Delete Component
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ) : (
                  <Card className="bg-card/50 backdrop-blur-sm border-border/30">
                    <CardContent className="p-6 text-center">
                      <Info className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">
                        Select a component to view its properties
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* Design Statistics */}
                <Card className="bg-card/50 backdrop-blur-sm border-border/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Info className="w-4 h-4 text-muted" />
                      Design Stats
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="bg-muted/30 rounded p-2 text-center">
                        <div className="text-muted-foreground">Components</div>
                        <div className="font-medium text-lg">{components.length}</div>
                      </div>
                      <div className="bg-muted/30 rounded p-2 text-center">
                        <div className="text-muted-foreground">Connections</div>
                        <div className="font-medium text-lg">{connections.length}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer tip */}
      <div className="p-4 border-t border-border/30 bg-gradient-to-r from-muted/20 via-card to-muted/10">
        <div className="text-xs text-muted-foreground">
          {activeTab === 'components' ? (
            <>🔧 <strong>Tip:</strong> Drag components from library to canvas</>
          ) : (
            <>⚙️ <strong>Tip:</strong> Click components to edit properties</>
          )}
        </div>
      </div>
    </div>
  );
}