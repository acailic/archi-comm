// Tauri integration layer for desktop functionality
// This provides a clean interface between the React app and potential Tauri backend

interface TauriAPI {
  saveDesign: (data: any, filename: string) => Promise<string>;
  loadDesign: (path?: string) => Promise<any>;
  exportDesign: (data: any, format: 'json' | 'png', filename: string) => Promise<string>;
  saveAudioRecording: (blob: Blob, filename: string) => Promise<string>;
  loadAudioRecording: (path: string) => Promise<Blob>;
  showSaveDialog: (defaultName: string, extensions: string[]) => Promise<string | null>;
  showOpenDialog: (extensions: string[]) => Promise<string | null>;
  showNotification: (title: string, message: string) => Promise<void>;
  getAppVersion: () => Promise<string>;
  setWindowTitle: (title: string) => Promise<void>;
  minimizeWindow: () => Promise<void>;
  maximizeWindow: () => Promise<void>;
  closeWindow: () => Promise<void>;
}

// Check if we're running in Tauri (this will be false in web environment)
const isTauri = () => {
  return typeof window !== 'undefined' && 
         (window as any).__TAURI__ !== undefined;
};

// Helper function to show browser notifications
const showBrowserNotification = async (title: string, message: string) => {
  if ('Notification' in window) {
    if (Notification.permission === 'granted') {
      new Notification(title, { 
        body: message,
        icon: '/favicon.ico'
      });
    } else if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        new Notification(title, { 
          body: message,
          icon: '/favicon.ico'
        });
      }
    }
  }
};

// Helper function to download files
const downloadFile = (content: string, filename: string, contentType: string = 'application/json') => {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

// Web-compatible implementations (these will work in any browser)
const webImplementations: TauriAPI = {
  async saveDesign(data: any, filename: string): Promise<string> {
    try {
      const json = JSON.stringify(data, null, 2);
      const key = `archicomm-design-${filename}`;
      localStorage.setItem(key, json);
      localStorage.setItem(`${key}-timestamp`, new Date().toISOString());
      
      await showBrowserNotification('ArchiComm', `Design saved: ${filename}`);
      return `Saved to local storage: ${filename}`;
    } catch (error) {
      console.error('Failed to save design:', error);
      throw new Error('Failed to save design');
    }
  },

  async loadDesign(path?: string): Promise<any> {
    try {
      if (!path) {
        // Show available designs in console for now
        const keys = Object.keys(localStorage).filter(key => key.startsWith('archicomm-design-'));
        console.log('Available designs:', keys);
        return null;
      }
      
      const key = path.startsWith('archicomm-design-') ? path : `archicomm-design-${path}`;
      const data = localStorage.getItem(key);
      
      if (!data) {
        throw new Error(`Design not found: ${path}`);
      }
      
      return JSON.parse(data);
    } catch (error) {
      console.error('Failed to load design:', error);
      return null;
    }
  },

  async exportDesign(data: any, format: 'json' | 'png', filename: string): Promise<string> {
    try {
      if (format === 'json') {
        const json = JSON.stringify(data, null, 2);
        downloadFile(json, `${filename}.json`, 'application/json');
        await showBrowserNotification('ArchiComm', `Design exported: ${filename}.json`);
        return `Exported ${filename}.json`;
      } else {
        // For PNG export, we'd need to render the canvas to image
        // For now, just export JSON
        const json = JSON.stringify(data, null, 2);
        downloadFile(json, `${filename}.json`, 'application/json');
        await showBrowserNotification('ArchiComm', `Design exported as JSON: ${filename}.json`);
        return `Exported ${filename}.json (PNG export not yet implemented)`;
      }
    } catch (error) {
      console.error('Failed to export design:', error);
      throw new Error('Failed to export design');
    }
  },

  async saveAudioRecording(blob: Blob, filename: string): Promise<string> {
    try {
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename}.webm`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      await showBrowserNotification('ArchiComm', `Audio saved: ${filename}.webm`);
      return `Saved ${filename}.webm`;
    } catch (error) {
      console.error('Failed to save audio:', error);
      throw new Error('Failed to save audio recording');
    }
  },

  async loadAudioRecording(path: string): Promise<Blob> {
    try {
      const response = await fetch(path);
      if (!response.ok) {
        throw new Error(`Failed to load audio: ${response.statusText}`);
      }
      return await response.blob();
    } catch (error) {
      console.error('Failed to load audio:', error);
      throw new Error('Failed to load audio recording');
    }
  },

  async showSaveDialog(defaultName: string, extensions: string[]): Promise<string | null> {
    // In web environment, we can't show native dialogs, so return a default name
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const extension = extensions[0] || 'json';
    return `${defaultName}-${timestamp}.${extension}`;
  },

  async showOpenDialog(extensions: string[]): Promise<string | null> {
    // In web environment, we'd typically use a file input
    // For now, return null to indicate no file selected
    console.log(`Open dialog requested for extensions: ${extensions.join(', ')}`);
    return null;
  },

  async showNotification(title: string, message: string): Promise<void> {
    await showBrowserNotification(title, message);
  },

  async getAppVersion(): Promise<string> {
    return '1.0.0-web';
  },

  async setWindowTitle(title: string): Promise<void> {
    document.title = title;
  },

  async minimizeWindow(): Promise<void> {
    console.log('Minimize window requested (web environment)');
    // In web, we can't actually minimize the window
  },

  async maximizeWindow(): Promise<void> {
    console.log('Maximize window requested (web environment)');
    // In web, we can try to fullscreen
    try {
      if (document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen();
      }
    } catch (error) {
      console.log('Fullscreen not supported or denied');
    }
  },

  async closeWindow(): Promise<void> {
    console.log('Close window requested (web environment)');
    // In web, we can suggest closing the tab
    if (confirm('Close ArchiComm?')) {
      window.close();
    }
  }
};

// Future Tauri implementations - these will use actual Tauri APIs when running in Tauri
// For now, they delegate to web implementations to avoid build errors
const tauriImplementations: TauriAPI = {
  ...webImplementations,
  
  // These implementations will be enabled when Tauri APIs are actually available
  // Currently commented out to prevent build errors with missing Tauri packages
  
  /*
  async saveDesign(data: any, filename: string): Promise<string> {
    // When running in actual Tauri app, this would use:
    // const { writeTextFile, BaseDirectory } = await import('@tauri-apps/api/fs');
    // For now, fall back to web implementation
    return await webImplementations.saveDesign(data, filename);
  },
  */
};

// Export the unified API - always use web implementations for now to avoid build errors
// When Tauri packages are available, this can be changed to: isTauri() ? tauriImplementations : webImplementations
export const tauriAPI: TauriAPI = webImplementations;

// Utility functions
export const isTauriApp = isTauri;

// Custom hooks for Tauri integration
export const useTauriAPI = () => {
  return tauriAPI;
};

// Window controls component props
export interface WindowControlsProps {
  showControls?: boolean;
  title?: string;
}

// Helper function to check if notifications are supported
export const isNotificationSupported = () => {
  return 'Notification' in window;
};

// Helper function to request notification permission
export const requestNotificationPermission = async (): Promise<boolean> => {
  // For web environment, use standard Notification API
  if (!isNotificationSupported()) {
    return false;
  }
  
  if (Notification.permission === 'granted') {
    return true;
  }
  
  if (Notification.permission !== 'denied') {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
  
  return false;
};

// Additional Tauri-specific utilities
export const tauriUtils = {
  // Get system information
  async getSystemInfo() {
    // In web environment, return basic browser info
    if (typeof navigator !== 'undefined') {
      return {
        platform: navigator.platform,
        userAgent: navigator.userAgent,
        language: navigator.language,
        cookieEnabled: navigator.cookieEnabled
      };
    }
    return null;
  },

  // Handle window events (web fallback)
  async setupWindowEvents() {
    if (typeof window !== 'undefined') {
      // Set up basic window event listeners for web
      window.addEventListener('beforeunload', (e) => {
        // This would emit 'app-closing' in Tauri
        console.log('Window closing');
      });

      window.addEventListener('focus', () => {
        // This would emit 'app-focused' in Tauri
        console.log('Window focused');
      });

      window.addEventListener('blur', () => {
        // This would emit 'app-blurred' in Tauri
        console.log('Window blurred');
      });

      return true;
    }
    return false;
  },

  // Handle file drag and drop (web fallback)
  async handleFileOpen() {
    if (typeof document !== 'undefined') {
      // Set up file drop listeners for web
      document.addEventListener('dragover', (e) => {
        e.preventDefault();
      });

      document.addEventListener('drop', (e) => {
        e.preventDefault();
        const files = Array.from(e.dataTransfer?.files || []);
        console.log('Files dropped:', files.map(f => f.name));
        // Handle file drop logic here
      });

      return true;
    }
    return false;
  },

  // Application menu management (web fallback)
  async createAppMenu() {
    // In web environment, we would create a custom menu component
    // For now, return null since we handle menus through React components
    console.log('Menu creation requested - using React components instead');
    return null;
  }
};