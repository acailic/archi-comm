
  # ArchiComm MVP Application

  This is a code bundle for ArchiComm MVP Application. The original project is available at https://www.figma.com/design/zeIuV525uE6nSLK2GVQgU5/ArchiComm-MVP-Application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  